'use strict';

const fs = require('fs');
const assert = require('assert');

assert.strictEqual(fs.foo, 'I am from the snapshot');
