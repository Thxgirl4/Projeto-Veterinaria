'use strict';
Object.defineProperty(
  Object.prototype,
  'flatten', {
    enumerable: false,
    // purposefully named something that
    // would never land in JS itself
    value: function smoosh() {}
  }
);
