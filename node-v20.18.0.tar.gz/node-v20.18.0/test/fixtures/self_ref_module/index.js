'use strict'

module.exports = 'Self resolution working';

