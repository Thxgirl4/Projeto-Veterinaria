# Usage and Example

## Usage

`node \[options\] index.js`

Please see the [Command Line Options][] document for more information.

## Example

An example of a [web server][] written with Node.js which responds with
`'Hello, World!'`:

## See also

Check out also [this guide][]

[Command Line Options]: cli.md#options
[this guide]: https://nodejs.org/
[web server]: example.md
