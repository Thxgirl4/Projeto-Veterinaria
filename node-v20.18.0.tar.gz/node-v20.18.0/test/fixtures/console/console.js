'use strict';

require('../../common');

console.trace('foo');
