'use strict';
const test = require('node:test');

test('this should be skipped');
test.only('this should be executed');
