'use strict';
const test = require('node:test');

test('d.cjs this should pass');
