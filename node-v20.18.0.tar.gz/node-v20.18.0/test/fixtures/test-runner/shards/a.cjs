'use strict';
const test = require('node:test');

test('a.cjs this should pass');
