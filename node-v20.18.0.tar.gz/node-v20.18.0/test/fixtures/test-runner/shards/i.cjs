'use strict';
const test = require('node:test');

test('i.cjs this should pass');
