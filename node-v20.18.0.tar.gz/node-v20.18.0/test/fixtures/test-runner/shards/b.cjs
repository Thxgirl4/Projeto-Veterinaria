'use strict';
const test = require('node:test');

test('b.cjs this should pass');
