'use strict';
const test = require('node:test');

test('c.cjs this should pass');
