'use strict';

Object.prototype.skip = true;
