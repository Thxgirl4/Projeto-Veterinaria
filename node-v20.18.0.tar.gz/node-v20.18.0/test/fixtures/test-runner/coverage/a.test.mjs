import{test as o}from"node:test";import{strictEqual as r}from"node:assert";function e(){r(1,2)}o("fails",()=>{e()});
//# sourceMappingURL=a.test.mjs.map
