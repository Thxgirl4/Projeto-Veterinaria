// Flags: --test-reporter=spec
'use strict';
require('../../../common');
const { it } = require('node:test');

it('should pass', () => {});
