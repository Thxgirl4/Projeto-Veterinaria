import 'dep-without-package-json/dep.js';
const identifier = 'package-type-module';
console.log(identifier);
export default identifier;
