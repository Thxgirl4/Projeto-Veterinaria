console.log(require.cache);
