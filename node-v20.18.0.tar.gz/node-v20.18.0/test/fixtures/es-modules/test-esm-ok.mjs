const isJs = true;
export default isJs;
