import cjs from './invalid-cjs.js';
