import { hello } from './imported-esm.mjs';
console.log(hello);
export { hello };
