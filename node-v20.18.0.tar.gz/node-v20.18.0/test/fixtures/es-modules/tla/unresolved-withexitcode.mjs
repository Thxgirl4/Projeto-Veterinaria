process.exitCode = 42;
await new Promise(() => {});
