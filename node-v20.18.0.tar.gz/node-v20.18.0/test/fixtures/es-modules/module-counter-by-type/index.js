let dummy = 42;

export {dummy};
